---
name: Add game template
about: Add a new game
title: Add [game name]
labels: game-addition
assignees: ''

---

<!--
Adding a new game?

It might be added already! Go to https://osgameclones.com/ and use the filter box!

Try the web forms here:

- Game: <https://osgameclones.com/add_game.html>
- Add original game: <https://osgameclones.com/add_original.html>
-->
